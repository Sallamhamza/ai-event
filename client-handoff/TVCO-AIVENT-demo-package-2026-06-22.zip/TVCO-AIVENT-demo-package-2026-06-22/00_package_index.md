# TVCO AIVENT Demo Package

Prepared: 22 June 2026

This folder contains the client handoff material for the AI Event Concierge demo. It is intended to be sent to TVCO or an event stakeholder before a review meeting or pilot discussion.

## Contents

1. `01_one_page_overview.pdf` - one-page client overview, generated from `01_one_page_overview.html`.
2. `02_demo_script_for_tvco_manager.md` - short presenter script for walking through the demo.
3. `03_test_questions_sheet.md` - English and Arabic questions for testing the concierge.
4. `04_mock_event_content_file.json` - editable mock event knowledge used by the demo.
5. `05_known_limitations_note.md` - practical limitations and recommended production fixes.
6. `06_pilot_proposal_next_step_offer.md` - suggested pilot scope and next steps.
7. `07_basic_user_instructions.md` - simple operating instructions for demo users.
8. `08_support_contact_note.md` - support handoff note with contact placeholders.
9. `09_screenshots_of_demo.md` - screenshot reference sheet.
10. `10_compliance_refusal_examples.md` - examples of compliant refusal behavior.
11. `11_branding_assets_used_in_demo.md` - colors, avatar assets, and visual notes.
12. `assets/` - copied visual assets used in the demo.
13. `screenshots/` - generated demo screenshots.

## Notes For Sending

- Do not include `.env.local` or API keys.
- For a stable client demo, set `USE_MOCK_AI=true` in the demo environment.
- The mock event content is fictional and should be replaced with approved TVCO/client content before any production pilot.
