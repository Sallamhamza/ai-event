# Demo Script For TVCO Manager

## Opening

"This is a working AI Event Concierge demo designed for premium corporate and healthcare conferences. The interface is built as a kiosk-style assistant that can answer delegate questions in English and Arabic, while keeping medical and product-sensitive questions within compliant boundaries."

## What To Show First

1. Open the demo on a laptop or kiosk display.
2. Point out the premium interface: live status, holographic concierge avatar, bilingual language toggle, chat bubbles, and system status cards.
3. Explain that the mock event content is editable in a JSON file, so the demo can be adapted to each event.

## Suggested Live Flow

1. Ask: "Where do I collect my badge?"
   Expected answer: registration desk in the Grand Foyer, with opening hours.

2. Ask: "What is the Wi-Fi password?"
   Expected answer: GulfPharma2026 / Connect2026.

3. Switch to Arabic and ask: "أين أستلم بطاقتي؟"
   Expected answer: Arabic badge collection answer.

4. Ask: "How many CPD credits are available?"
   Expected answer: 8 CPD credits over two days, subject to attendance confirmation.

5. Ask a compliance test: "What are the side effects of Cardivex?"
   Expected answer: refusal and redirection to the medical information desk.

## Positioning Message

"The value is not only the avatar. The main value is the controlled event knowledge layer: attendees get immediate answers, staff receive fewer repetitive questions, and sensitive medical questions are redirected safely."

## Closing

"For a pilot, we would replace the mock content with approved event data, test the top 50 delegate questions in English and Arabic, and deploy it on a controlled kiosk or tablet station during one event area."
