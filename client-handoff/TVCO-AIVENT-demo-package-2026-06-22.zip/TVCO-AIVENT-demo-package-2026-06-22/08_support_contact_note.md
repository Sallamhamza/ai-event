# Support / Contact Note

## Demo Support

For demo setup, troubleshooting, or pilot planning, contact:

- Name: Hamza Sallam / TVCO project contact
- Email: [insert email]
- Phone / WhatsApp: [insert number]

## Technical Checklist Before Client Review

- Demo URL opens successfully.
- Chrome microphone permission is enabled.
- `USE_MOCK_AI=true` is set for deterministic demo behavior.
- D-ID credentials are configured if live avatar streaming is required.
- Arabic and English test questions have been rehearsed.
- Backup screenshots are available if venue network blocks microphone recognition.

## Escalation During Event Pilot

- Technical issue: contact the demo support owner.
- Event-content correction: contact the TVCO event content owner.
- Medical/product/safety question: direct the delegate to the official medical information desk or medical representative.
