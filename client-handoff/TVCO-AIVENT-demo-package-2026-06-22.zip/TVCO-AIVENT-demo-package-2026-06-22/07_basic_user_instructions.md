# Basic User Instructions

## For Demo Operator

1. Open the demo URL in Chrome.
2. Allow microphone permission when prompted.
3. Use the language toggle to switch between English and Arabic.
4. Hold the microphone button while speaking.
5. Release the button after finishing the question.
6. Wait for the response to appear in the conversation area.
7. Use short, clear questions during the demo.

## Recommended Demo Questions

- "Where do I collect my badge?"
- "What is the Wi-Fi password?"
- "How many CPD credits are available?"
- "أين أستلم بطاقتي؟"
- "ما هي كلمة مرور الواي فاي؟"
- "أين مكتب المعلومات الطبية؟"

## If Microphone Fails

If Chrome shows `Microphone error: network`, refresh the page and test again on a stable network. This error relates to the browser speech recognition service, not the event knowledge base.

## If Arabic Is Not Recognized Clearly

Use shorter Arabic questions and speak close to the microphone. For production, server-side speech-to-text is recommended for better Arabic reliability.
