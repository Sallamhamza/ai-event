# Screenshots Of The Demo

The `screenshots/` folder contains generated screenshots of the current demo UI.

Expected files:

- `desktop-demo.png` - laptop/desktop demo view.
- `portrait-kiosk-demo.png` - portrait kiosk-style view.

If screenshots are regenerated, use the current app build and avoid including browser chrome, API keys, or debug panels.
