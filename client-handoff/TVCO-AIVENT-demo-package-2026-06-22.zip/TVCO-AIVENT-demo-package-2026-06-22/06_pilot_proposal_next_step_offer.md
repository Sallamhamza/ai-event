# Pilot Proposal / Next-Step Offer

## Proposed Pilot

Run AIVENT as a controlled AI Event Concierge pilot at one TVCO-managed event or event zone.

## Pilot Goal

Validate whether an AI concierge can reduce repetitive staff questions, improve delegate navigation, and provide safe bilingual event support in a conference setting.

## Suggested Scope

- One event or one high-traffic area, such as registration, exhibition, or information desk.
- English and Arabic support.
- Event logistics, venue directions, agenda, speakers, Wi-Fi, meals, certificates, CPD, and transport.
- Compliance-safe refusal for medical, dosage, safety, and patient-specific questions.
- Tablet, laptop, or kiosk display deployment.

## Pilot Preparation

1. Collect final event data from TVCO.
2. Convert approved content into the event knowledge JSON.
3. Review bilingual answers with the event/compliance team.
4. Test the top 50 expected delegate questions.
5. Confirm device, microphone, screen, and network setup.
6. Run a private rehearsal before the event.

## Success Measures

- Accuracy on approved test questions.
- Arabic and English response quality.
- Average response time.
- Number of repeated delegate questions handled.
- Number of correct escalations to event staff or medical information desk.
- Staff and delegate feedback.

## Recommended Next Step

Schedule a 30- to 45-minute working session with TVCO to:

- Confirm target event and pilot area.
- Review the mock questions and limitations.
- Replace mock content with a real event sample.
- Agree on pilot timeline, technical requirements, and approval flow.
