# Branding Assets Used In The Demo

## Visual Direction

- Premium corporate AI concierge.
- Dark navy background with subtle gradients.
- Electric blue and cyan accents.
- Rounded kiosk layout suitable for laptop demo mode and portrait displays.
- Holographic AI-core avatar treatment.

## Main Assets

The `assets/` folder includes copied demo assets:

- `male-avatar-hologram.png` - primary hologram avatar fallback image.
- `nour-avatar.png` - earlier avatar/reference asset retained for demo context.
- `next.svg`, `vercel.svg`, `globe.svg`, `file.svg`, `window.svg` - default project assets still present in the app public folder.

## Core Colors

| Use | Color |
|---|---|
| Deep background | `#020713`, `#04101f`, `#06172b` |
| Cyan accent | `#20dfff` |
| Green/live accent | `#2cf2a7` |
| Panel border | `rgba(93, 220, 255, 0.22)` |
| Main text | `rgba(239, 250, 255, 0.94)` |

## Naming Note

The UI presents the assistant as AIVENT. The mock event content may refer to Nour as the example concierge persona. For client presentation, position AIVENT as the product/interface and Nour as a replaceable event persona.
